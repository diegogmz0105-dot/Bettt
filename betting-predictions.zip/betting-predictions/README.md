# Sistema de Predicciones Deportivas

Proyecto universitario de Sistemas: aplicación web cliente-servidor que consume una **API real de deportes** y genera predicciones de partidos a partir de un algoritmo basado en estadísticas.

## Arquitectura

```
Navegador (HTML/CSS/JS)
        │  fetch()
        ▼
Servidor Node.js + Express  ───►  API pública TheSportsDB
   (server.js)                     (datos reales de equipos y partidos)
```

- **Frontend** (`/public`): interfaz donde el usuario busca dos equipos, elige quién juega de local y visualiza la predicción con barras de probabilidad.
- **Backend** (`server.js`): expone dos endpoints propios, actúa como intermediario ("proxy") hacia la API externa y contiene la lógica de cálculo.
- **API externa**: [TheSportsDB](https://www.thesportsdb.com/api.php) (gratuita, incluye fútbol, básquet y muchos otros deportes). Se usa la clave de pruebas pública `3`, sin necesidad de registro.

## Endpoints del backend

| Método | Ruta | Descripción |
|---|---|---|
| GET | `/api/team/search?name=NOMBRE` | Busca equipos por nombre |
| GET | `/api/predict?teamAId=ID&teamBId=ID&homeTeam=A\|B\|none` | Devuelve la predicción del enfrentamiento |

## Algoritmo de predicción

Para cada equipo se consultan sus **últimos 5 partidos reales**:

1. **% de victorias (`winRate`)**: victorias / partidos jugados.
2. **Forma reciente ponderada (`formaReciente`)**: promedio de resultados (1 = victoria, 0.5 = empate, 0 = derrota) donde los partidos más recientes pesan más:
   `pesos = [0.35, 0.25, 0.20, 0.12, 0.08]`
3. **Puntaje final**: `score = winRate * 0.5 + formaReciente * 0.5`
4. **Bono de localía**: si un equipo juega en casa, se le suma `+0.15` a su puntaje.
5. **Normalización**: las probabilidades finales se calculan como `scoreEquipo / (scoreA + scoreB)`, para que sumen 100%.

Este enfoque es intencionalmente simple y transparente para que puedas explicarlo y, si tu profesor lo pide, ampliarlo (por ejemplo agregando enfrentamientos directos, goles a favor/en contra, o pesos distintos).

## Cómo ejecutarlo

Requiere [Node.js](https://nodejs.org) 18 o superior (necesita conexión a internet para consultar la API).

```bash
cd betting-predictions
npm install
npm start
```

Luego abre `http://localhost:3000` en tu navegador.

## Ideas para extender el trabajo

- Guardar el historial de predicciones en una base de datos (SQLite/MongoDB).
- Agregar autenticación de usuarios para guardar predicciones favoritas.
- Comparar la predicción con el resultado real una vez jugado el partido (para medir precisión).
- Añadir más ligas/deportes filtrando por `strSport` en la respuesta de la API.

## Aviso

Este proyecto es un ejercicio académico de programación (consumo de APIs, arquitectura cliente-servidor y diseño de algoritmos). No está pensado para apuestas reales con dinero.
